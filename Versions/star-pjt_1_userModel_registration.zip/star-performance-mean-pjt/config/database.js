module.exports = {
    database: 'mongodb://localhost:27017/star-auth',
    secret: 'yoursecret'
}
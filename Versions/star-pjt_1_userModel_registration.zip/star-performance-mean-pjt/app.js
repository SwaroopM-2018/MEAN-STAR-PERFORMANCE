const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const passport = require('passport');
const mongoose = require('mongoose');
const config = require('./config/database');


//making database connection
mongoose.connect(config.database,{ useNewUrlParser: true });
mongoose.connection.on('connected', () =>{
    console.log('Connected to database:' +config.database);
});
//on Erro connecting to DB
mongoose.connection.on('error', (err) =>{
    console.log('Database Error: ' +err);
});


const app = express();

//REquired for routes:
const users = require('./routes/users');

//Port number
const port = 3000;

//Middleware
//add cors middleware - which will allow us to make a request to our api from different domain name
app.use(cors());
//add body parser middleware - parse incoming body , like when u submit form u can get the body
app.use(bodyParser.json());
// add passport middleware for authentication
app.use(passport.initialize());
app.use(passport.session());

require('./config/passport')(passport);


// Set Static Folder
app.use(express.static(path.join(__dirname,'public')));

//use the router
app.use('/users', users);


app.get('/', (req,res) =>{
    res.send('Invalid Endpoint');
});

//server start
app.listen(port, () =>{
    console.log('Server started on port ' +port);
});


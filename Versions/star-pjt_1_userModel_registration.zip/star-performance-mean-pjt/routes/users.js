const express = require("express");
const router = express.Router();
const passport = require('passport');
const jwt = require('jsonwebtoken');
const config = require('../config/database');
const User = require('../models/user');

//Register
router.post('/register', (req,res,next)=>{
    let newUser = new User({
        name: req.body.name,
        username: req.body.username,
        password: req.body.password,
        email: req.body.email,
        group: 'Readonly'
    });

    User.addUser(newUser,(err, user) =>{
        if(err){
            res.json({success: false, msg:'Failed to register User'});
        } else {
            res.json({success: true, msg:'User Registered'});
        }
    });
});

//Authenticate
router.post('/authenticate', ( req, res, next)=>{
    const EmpID = req.body.EmpID;
    const Passwd = req.body.Passwd;

    User.getUserByEmpID(EmpID, (err, user) =>{
        if(err) throw err;
        if(!user){
            return res.json({success: false, msg:'User Not found'});
        }
        User.comparePassword(Passwd, user.Passwd, (err, isMatch) =>{
            if(err) throw err;
            if(isMatch){
                const token = jwt.sign(user, config.secret, { 
                    expiresIn: 6080
                });
                res.json({
                    success: true,
                    token: 'JWT '+token,
                    user: {
                        id: user._id,
                        EmpID: user.EmpID,
                        Email: user.Email
                    }
                });
            } else {
                return res.json({success: false, msg: 'Wrong password'});
            }
        });
    });
});

//Profile -- this will be tokenized n user access to be provided
router.get('/profile', (req,res,next)=>{
    res.send('PROFILE');
});
//

//export the router
module.exports = router;
